var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var M, MqttActionHandler, MqttActionProvider, Promise;
  Promise = env.require('bluebird');
  M = env.matcher;
  MqttActionHandler = (function(superClass) {
    extend(MqttActionHandler, superClass);

    function MqttActionHandler(framework, mqttclient, stringTopic1, stringMessage1, stringQoS1, stringRetain1) {
      this.framework = framework;
      this.mqttclient = mqttclient;
      this.stringTopic = stringTopic1;
      this.stringMessage = stringMessage1;
      this.stringQoS = stringQoS1;
      this.stringRetain = stringRetain1;
    }

    MqttActionHandler.prototype.executeAction = function(simulate) {
      return this.framework.variableManager.evaluateStringExpression(this.stringTopic).then((function(_this) {
        return function(strTopic) {
          return _this.framework.variableManager.evaluateStringExpression(_this.stringMessage).then(function(strMessage) {
            return _this.framework.variableManager.evaluateExpression(_this.stringQoS).then(function(strQoS) {
              return _this.framework.variableManager.evaluateExpression(_this.stringRetain).then(function(strRet) {
                var numQoS, retFlag;
                if (simulate) {
                  return Promise.resolve("publish mqtt message " + strMessage + " on topic " + strTopic + " qos: " + strQoS + " retain: " + strRet);
                } else {
                  retFlag = strRet === "true" ? true : false;
                  numQoS = Number(strQoS);
                  _this.mqttclient.publish(strTopic, strMessage, {
                    qos: numQoS,
                    retain: retFlag
                  });
                  return Promise.resolve("publish mqtt message " + strMessage + " on topic " + strTopic + " qos: " + strQoS + " retain: " + strRet);
                }
              });
            });
          });
        };
      })(this));
    };

    return MqttActionHandler;

  })(env.actions.ActionHandler);
  MqttActionProvider = (function(superClass) {
    extend(MqttActionProvider, superClass);

    function MqttActionProvider(framework, mqttclient) {
      this.framework = framework;
      this.mqttclient = mqttclient;
    }

    MqttActionProvider.prototype.parseAction = function(input, context) {
      var m, match, next, setMessageString, setTopicString, strToTokens, stringMessage, stringQoS, stringRetain, stringTopic;
      strToTokens = (function(_this) {
        return function(str) {
          return ["\"" + str + "\""];
        };
      })(this);
      stringMessage = null;
      stringTopic = null;
      stringQoS = strToTokens('0');
      stringRetain = strToTokens("false");
      match = null;
      setMessageString = (function(_this) {
        return function(m, tokens) {
          return stringMessage = tokens;
        };
      })(this);
      setTopicString = (function(_this) {
        return function(m, tokens) {
          return stringTopic = tokens;
        };
      })(this);
      m = M(input, context).match('publish mqtt message ').matchStringWithVars(setMessageString).match(' on topic ').matchStringWithVars(setTopicString);
      next = m.match(' qos: ').match(['0', '1', '2'], (function(_this) {
        return function(next, q) {
          stringQoS = strToTokens(q);
          if (next.hadMatch()) {
            return m = next;
          }
        };
      })(this));
      next = m.match(' retain: ').match(['false', 'true'], (function(_this) {
        return function(next, r) {
          stringRetain = strToTokens(r);
          if (next.hadMatch()) {
            return m = next;
          }
        };
      })(this));
      if (m.hadMatch()) {
        match = m.getFullMatch();
        return {
          token: match,
          nextInput: input.substring(match.length),
          actionHandler: new MqttActionHandler(this.framework, this.mqttclient, stringTopic, stringMessage, stringQoS, stringRetain)
        };
      }
    };

    return MqttActionProvider;

  })(env.actions.ActionProvider);
  return MqttActionProvider;
};
