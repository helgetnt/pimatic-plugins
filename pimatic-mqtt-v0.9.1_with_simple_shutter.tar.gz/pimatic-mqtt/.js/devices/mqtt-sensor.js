var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var MqttSensor, Promise, flatten;
  Promise = env.require('bluebird');
  flatten = require('flat');
  return MqttSensor = (function(superClass) {
    extend(MqttSensor, superClass);

    function MqttSensor(config, plugin) {
      var attr, fn, i, j, len, ref;
      this.config = config;
      this.plugin = plugin;
      this.name = this.config.name;
      this.id = this.config.id;
      this.attributes = {};
      this.mqttvars = [];
      if (this.plugin.connected) {
        this.onConnect();
      }
      this.plugin.mqttclient.on('connect', (function(_this) {
        return function() {
          return _this.onConnect();
        };
      })(this));
      this.plugin.mqttclient.on('message', (function(_this) {
        return function(topic, message) {
          var attr, i, j, len, ref, results;
          ref = _this.config.attributes;
          results = [];
          for (i = j = 0, len = ref.length; j < len; i = ++j) {
            attr = ref[i];
            results.push((function(attr) {
              var data, flat, key, value;
              if (attr.topic === topic) {
                _this.mqttvars[topic] = message.toString();
                try {
                  data = JSON.parse(message);
                } catch (undefined) {}
                if (typeof data === 'object' && Object.keys(data).length !== 0) {
                  flat = flatten(data);
                  for (key in flat) {
                    value = flat[key];
                    if (key === attr.name) {
                      if (attr.type === 'number') {
                        if (attr.division) {
                          _this.emit(attr.name, Number("" + value) / attr.division);
                          return;
                        }
                        if (attr.multiplier) {
                          _this.emit(attr.name, Number("" + value) * attr.multiplier);
                          return;
                        } else {
                          _this.emit(attr.name, Number("" + value));
                        }
                      } else {
                        _this.emit(attr.name, "" + value);
                      }
                    }
                  }
                } else {
                  if (attr.type === 'number') {
                    if (attr.division) {
                      _this.emit(attr.name, Number(message) / attr.division);
                      return;
                    }
                    if (attr.multiplier) {
                      _this.emit(attr.name, Number(message) * attr.multiplier);
                    } else {
                      return _this.emit(attr.name, Number(message));
                    }
                  } else {
                    if (attr.messageMap && attr.messageMap[message]) {
                      _this.emit(attr.name, attr.messageMap[message]);
                    } else {
                      return _this.emit(attr.name, message.toString());
                    }
                  }
                }
              }
            })(attr));
          }
          return results;
        };
      })(this));
      ref = this.config.attributes;
      fn = (function(_this) {
        return function(attr) {
          var getter, name;
          name = attr.name;
          _this.attributes[name] = {
            description: name
          };
          _this.attributes[name].description = name;
          _this.attributes[name].type = attr.type;
          _this.attributes[name].unit = attr.unit || '';
          _this.attributes[name].discrete = attr.discrete || false;
          _this.attributes[name].acronym = attr.acronym || null;
          getter = (function() {
            var value;
            if (attr.type === 'number') {
              value = Number(_this.mqttvars[attr.topic]);
            } else {
              value = _this.mqttvars[attr.topic];
            }
            return Promise.resolve(value);
          });
          return _this._createGetter(name, getter);
        };
      })(this);
      for (i = j = 0, len = ref.length; j < len; i = ++j) {
        attr = ref[i];
        fn(attr);
      }
      MqttSensor.__super__.constructor.call(this);
    }

    MqttSensor.prototype.onConnect = function() {
      var attr, i, j, len, ref, results;
      ref = this.config.attributes;
      results = [];
      for (i = j = 0, len = ref.length; j < len; i = ++j) {
        attr = ref[i];
        results.push((function(_this) {
          return function(attr) {
            var _qos;
            _qos = attr.qos || 0;
            return _this.plugin.mqttclient.subscribe(attr.topic, {
              qos: _qos
            });
          };
        })(this)(attr));
      }
      return results;
    };

    MqttSensor.prototype.destroy = function() {
      var attr, fn, i, j, len, ref;
      ref = this.config.attributes;
      fn = (function(_this) {
        return function(attr) {
          return _this.plugin.mqttclient.unsubscribe(attr.topic);
        };
      })(this);
      for (i = j = 0, len = ref.length; j < len; i = ++j) {
        attr = ref[i];
        fn(attr);
      }
      return MqttSensor.__super__.destroy.call(this);
    };

    return MqttSensor;

  })(env.devices.Sensor);
};
