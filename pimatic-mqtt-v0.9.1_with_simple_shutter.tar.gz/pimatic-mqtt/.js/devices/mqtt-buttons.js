var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var MqttButtons, Promise;
  Promise = env.require('bluebird');
  return MqttButtons = (function(superClass) {
    extend(MqttButtons, superClass);

    function MqttButtons(config, plugin) {
      var b, i, len, ref;
      this.config = config;
      this.plugin = plugin;
      this.name = this.config.name;
      this.id = this.config.id;
      if (this.plugin.connected) {
        this.onConnect();
      }
      this.plugin.mqttclient.on('connect', (function(_this) {
        return function() {
          return _this.onConnect();
        };
      })(this));
      ref = this.config.buttons;
      for (i = 0, len = ref.length; i < len; i++) {
        b = ref[i];
        if (b.stateTopic) {
          this.plugin.mqttclient.on('message', (function(_this) {
            return function(topic, message) {
              var payload;
              if (b.stateTopic === topic) {
                payload = message.toString();
              }
              if (payload === b.message) {
                return _this.emit('button', b.id);
              }
            };
          })(this));
        }
      }
      MqttButtons.__super__.constructor.call(this, this.config);
    }

    MqttButtons.prototype.buttonPressed = function(buttonId) {
      var b, i, len, ref;
      ref = this.config.buttons;
      for (i = 0, len = ref.length; i < len; i++) {
        b = ref[i];
        if (b.id === buttonId) {
          this.emit('button', b.id);
          this.plugin.mqttclient.publish(b.topic, b.message, {
            qos: b.qos || 0
          });
          return;
        }
      }
    };

    MqttButtons.prototype.onConnect = function() {
      var b, i, len, ref, results;
      ref = this.config.buttons;
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        b = ref[i];
        if (b.stateTopic) {
          results.push(this.plugin.mqttclient.subscribe(b.stateTopic, {
            qos: b.qos || 0
          }));
        } else {
          results.push(void 0);
        }
      }
      return results;
    };

    MqttButtons.prototype.destroy = function() {
      var b, i, len, ref;
      ref = this.config.buttons;
      for (i = 0, len = ref.length; i < len; i++) {
        b = ref[i];
        if (b.stateTopic) {
          this.plugin.mqttclient.unsubscribe(b.stateTopic);
        }
      }
      return MqttButtons.__super__.destroy.call(this);
    };

    return MqttButtons;

  })(env.devices.ButtonsDevice);
};
