var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var MqttPresenceSensor, Promise;
  Promise = env.require('bluebird');
  return MqttPresenceSensor = (function(superClass) {
    extend(MqttPresenceSensor, superClass);

    function MqttPresenceSensor(config, plugin, lastState) {
      var ref;
      this.config = config;
      this.plugin = plugin;
      this.id = this.config.id;
      this.name = this.config.name;
      this._presence = (lastState != null ? (ref = lastState.presence) != null ? ref.value : void 0 : void 0) || false;
      if (this.plugin.connected) {
        this.onConnect();
      }
      this.plugin.mqttclient.on('connect', (function(_this) {
        return function() {
          return _this.onConnect();
        };
      })(this));
      this.plugin.mqttclient.on('message', (function(_this) {
        return function(topic, message) {
          if (_this.config.topic === topic) {
            switch (message.toString()) {
              case _this.config.onMessage:
                return _this._setPresence(true);
              case _this.config.offMessage:
                return _this._setPresence(false);
              default:
                return env.logger.debug(_this.name + " with id:" + _this.id + ": Message is not harmony with onMessage or offMessage in config.json or with default values");
            }
          }
        };
      })(this));
      MqttPresenceSensor.__super__.constructor.call(this);
    }

    MqttPresenceSensor.prototype.onConnect = function() {
      return this.plugin.mqttclient.subscribe(this.config.topic, {
        qos: this.config.qos
      });
    };

    MqttPresenceSensor.prototype.getPresence = function() {
      return Promise.resolve(this._presence);
    };

    MqttPresenceSensor.prototype.destroy = function() {
      this.plugin.mqttclient.unsubscribe(this.config.topic);
      return MqttPresenceSensor.__super__.destroy.call(this);
    };

    return MqttPresenceSensor;

  })(env.devices.PresenceSensor);
};
