var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var MqttSwitch, Promise;
  Promise = env.require('bluebird');
  return MqttSwitch = (function(superClass) {
    extend(MqttSwitch, superClass);

    function MqttSwitch(config, plugin, lastState) {
      var ref;
      this.config = config;
      this.plugin = plugin;
      this.name = this.config.name;
      this.id = this.config.id;
      this._state = (lastState != null ? (ref = lastState.state) != null ? ref.value : void 0 : void 0) || false;
      if (this.plugin.connected) {
        this.onConnect();
      }
      this.plugin.mqttclient.on('connect', (function(_this) {
        return function() {
          return _this.onConnect();
        };
      })(this));
      if (this.config.stateTopic) {
        this.plugin.mqttclient.on('message', (function(_this) {
          return function(topic, message) {
            if (_this.config.stateTopic === topic) {
              switch (message.toString()) {
                case _this.config.onMessage:
                  _this._setState(true);
                  _this._state = true;
                  return _this.emit("state", true);
                case _this.config.offMessage:
                  _this._setState(false);
                  _this._state = false;
                  return _this.emit("state", false);
                default:
                  return env.logger.debug(_this.name + " with id:" + _this.id + ": Message is not harmony with onMessage or offMessage in config.json or with default values");
              }
            }
          };
        })(this));
      }
      MqttSwitch.__super__.constructor.call(this);
    }

    MqttSwitch.prototype.onConnect = function() {
      if (this.config.stateTopic) {
        return this.plugin.mqttclient.subscribe(this.config.stateTopic, {
          qos: this.config.qos
        });
      }
    };

    MqttSwitch.prototype.changeStateTo = function(state) {
      var message;
      message = (state ? this.config.onMessage : this.config.offMessage);
      this.plugin.mqttclient.publish(this.config.topic, message, {
        qos: this.config.qos,
        retain: this.config.retain
      });
      this._setState(state);
      return Promise.resolve();
    };

    MqttSwitch.prototype.destroy = function() {
      if (this.config.stateTopic) {
        this.plugin.mqttclient.unsubscribe(this.config.stateTopic);
      }
      return MqttSwitch.__super__.destroy.call(this);
    };

    return MqttSwitch;

  })(env.devices.PowerSwitch);
};
