var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var MqttDimmer, Promise;
  Promise = env.require('bluebird');
  return MqttDimmer = (function(superClass) {
    extend(MqttDimmer, superClass);

    function MqttDimmer(config, plugin, lastState) {
      var ref, ref1;
      this.config = config;
      this.plugin = plugin;
      this.name = this.config.name;
      this.id = this.config.id;
      this._state = (lastState != null ? (ref = lastState.state) != null ? ref.value : void 0 : void 0) || false;
      this._dimlevel = (lastState != null ? (ref1 = lastState.dimlevel) != null ? ref1.value : void 0 : void 0) || 0;
      this.resolution = (this.config.resolution - 1) || 255;
      if (this.plugin.connected) {
        this.onConnect();
      }
      this.plugin.mqttclient.on('connect', (function(_this) {
        return function() {
          return _this.onConnect();
        };
      })(this));
      if (this.config.stateTopic) {
        this.plugin.mqttclient.on('message', (function(_this) {
          return function(topic, message) {
            var payload;
            if (_this.config.stateTopic === topic) {
              payload = message.toString();
              _this.getPerCentlevel(payload);
              if (_this.perCentlevel !== _this._dimlevel) {
                _this._setDimlevel(_this.perCentlevel);
                return _this.emit(_this.dimlevel, _this.perCentlevel);
              }
            }
          };
        })(this));
      }
      MqttDimmer.__super__.constructor.call(this);
    }

    MqttDimmer.prototype.onConnect = function() {
      if (this.config.stateTopic) {
        return this.plugin.mqttclient.subscribe(this.config.stateTopic, {
          qos: this.config.qos
        });
      }
    };

    MqttDimmer.prototype.getDevLevel = function(perCentlevel) {
      this.devLevel = (perCentlevel * (this.resolution / 100)).toFixed(0);
      return this.devLevel;
    };

    MqttDimmer.prototype.getPerCentlevel = function(devlevel) {
      var perCentlevel;
      perCentlevel = ((devlevel * 100) / this.resolution).toFixed(0);
      this.perCentlevel = parseInt(perCentlevel, 10);
      return this.perCentlevel;
    };

    MqttDimmer.prototype.turnOn = function() {
      this.getDevLevel(100);
      this.plugin.mqttclient.publish(this.config.topic, this.devLevel, {
        qos: this.config.qos,
        retain: this.config.retain
      });
      return Promise.resolve();
    };

    MqttDimmer.prototype.turnOff = function() {
      this.plugin.mqttclient.publish(this.config.topic, 0, {
        qos: this.config.qos,
        retain: this.config.retain
      });
      return Promise.resolve();
    };

    MqttDimmer.prototype.changeDimlevelTo = function(dimlevel) {
      this.getDevLevel(dimlevel);
      this.plugin.mqttclient.publish(this.config.topic, this.devLevel, {
        qos: this.config.qos,
        retain: this.config.retain
      });
      this._setDimlevel(dimlevel);
      return Promise.resolve();
    };

    MqttDimmer.prototype.getDimlevel = function() {
      return Promise.resolve(this._dimlevel);
    };

    MqttDimmer.prototype.destroy = function() {
      if (this.config.stateTopic) {
        this.plugin.mqttclient.unsubscribe(this.config.stateTopic);
      }
      return MqttDimmer.__super__.destroy.call(this);
    };

    return MqttDimmer;

  })(env.devices.DimmerActuator);
};
