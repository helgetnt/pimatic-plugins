var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var MqttActionProvider, MqttPlugin, Promise, className, device, deviceTypes, i, len, mqtt, ref;
  mqtt = require('mqtt');
  Promise = env.require('bluebird');
  deviceTypes = {};
  ref = ['mqtt-switch', 'mqtt-shutter', 'mqtt-dimmer', 'mqtt-sensor', 'mqtt-presence-sensor', 'mqtt-contact-sensor', 'mqtt-buttons'];
  for (i = 0, len = ref.length; i < len; i++) {
    device = ref[i];
    className = device.replace(/(^[a-z])|(\-[a-z])/g, function($1) {
      return $1.toUpperCase().replace('-', '');
    });
    deviceTypes[className] = require('./devices/' + device)(env);
  }
  MqttActionProvider = require('./predicates_and_actions/mqtt_action')(env);
  MqttPlugin = (function(superClass) {
    extend(MqttPlugin, superClass);

    function MqttPlugin() {
      this.init = bind(this.init, this);
      return MqttPlugin.__super__.constructor.apply(this, arguments);
    }

    MqttPlugin.prototype.init = function(app, framework, config1) {
      var Connection, classType, deviceConfigDef, options;
      this.framework = framework;
      this.config = config1;
      this.connected = false;
      options = {
        host: this.config.host,
        port: this.config.port,
        username: this.config.username,
        password: this.config.password ? new Buffer(this.config.password) : false,
        keepalive: this.config.keepalive,
        clientId: this.config.clientId || 'pimatic_' + Math.random().toString(16).substr(2, 8),
        protocolId: this.config.protocolId,
        protocolVersion: this.config.protocolVer,
        clean: this.config.cleanSession,
        reconnectPeriod: this.config.reconnect,
        connectTimeout: this.config.timeout,
        queueQoSZero: this.config.queueQoSZero,
        ca: this.config.ca,
        certPath: this.config.certPath,
        keyPath: this.config.keyPath,
        rejectUnauthorized: this.config.rejectUnauthorized
      };
      if (this.config.ca && this.config.certPath && this.config.keyPath) {
        options.protocol = 'mqtts';
      }
      Connection = new Promise((function(_this) {
        return function(resolve, reject) {
          _this.mqttclient = new mqtt.connect(options);
          _this.mqttclient.on("connect", function() {
            _this.connected = true;
            env.logger.info("Successfully connected to MQTT Broker");
            return resolve();
          });
          _this.mqttclient.on('error', reject);
        };
      })(this)).timeout(60000)["catch"](function(error) {
        env.logger.error("Error on connecting to MQTT Broker " + error.message);
        env.logger.debug(error.stack);
      });
      this.mqttclient.on('reconnect', (function(_this) {
        return function() {
          return env.logger.info("Reconnecting to MQTT Broker");
        };
      })(this));
      this.mqttclient.on('offline', function() {
        this.connected = false;
        return env.logger.info("MQTT Broker is offline");
      });
      this.mqttclient.on('error', function(error) {
        this.connected = false;
        env.logger.error("connection error: " + error);
        return env.logger.debug(error.stack);
      });
      this.mqttclient.on('close', function() {
        this.connected = false;
        return env.logger.debug("Connection with MQTT Broker was closed");
      });
      deviceConfigDef = require("./device-config-schema");
      for (className in deviceTypes) {
        classType = deviceTypes[className];
        env.logger.debug("Registering device class " + className);
        this.framework.deviceManager.registerDeviceClass(className, {
          configDef: deviceConfigDef[className],
          createCallback: this.callbackHandler(className, classType)
        });
      }
      return this.framework.ruleManager.addActionProvider(new MqttActionProvider(this.framework, this.mqttclient));
    };

    MqttPlugin.prototype.callbackHandler = function(className, classType) {
      return (function(_this) {
        return function(config, lastState) {
          return new classType(config, _this, lastState);
        };
      })(this);
    };

    return MqttPlugin;

  })(env.plugins.Plugin);
  return new MqttPlugin;
};
