var bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

module.exports = function(env) {
  var M, Promise, ShellActionHandler, ShellActionProvider, ShellExecute, ShellPresenceSensor, ShellSensor, ShellShutter, ShellSwitch, child_process, commons, exec, plugin, settled, transformError;
  Promise = env.require('bluebird');
  commons = require('pimatic-plugin-commons')(env);
  M = env.matcher;
  child_process = require("child_process");
  exec = function(command) {
    return new Promise(function(resolve, reject) {
      return child_process.exec(command, function(err, stdout, stderr) {
        if (err) {
          if (stdout != null) {
            err.stdout = stdout.toString();
          }
          if (stderr != null) {
            err.stderr = stderr.toString();
          }
          return reject(err);
        }
        return resolve({
          stdout: stdout.toString(),
          stderr: stderr.toString()
        });
      });
    });
  };
  settled = function(promise) {
    return Promise.settle([promise]);
  };
  transformError = (function(_this) {
    return function(error) {
      var cause;
      if ((error.code != null) && (error.cause != null)) {
        cause = String(error.cause).replace(/(\r\n|\n|\r)/gm, " ").trim();
        error = new Error("Command execution failed with exit code " + error.code + " (" + cause + ")");
      }
      return error;
    };
  })(this);
  ShellExecute = (function(superClass) {
    extend(ShellExecute, superClass);

    function ShellExecute() {
      this.init = bind(this.init, this);
      return ShellExecute.__super__.constructor.apply(this, arguments);
    }

    ShellExecute.prototype.init = function(app, framework, config1) {
      var deviceConfigDef, lastAction, realExec;
      this.framework = framework;
      this.config = config1;
      this.framework.ruleManager.addActionProvider(new ShellActionProvider(this.framework));
      deviceConfigDef = require("./device-config-schema");
      this.framework.deviceManager.registerDeviceClass("ShellSwitch", {
        configDef: deviceConfigDef.ShellSwitch,
        createCallback: (function(_this) {
          return function(config, lastState) {
            return new ShellSwitch(config, lastState);
          };
        })(this)
      });
      this.framework.deviceManager.registerDeviceClass("ShellShutter", {
        configDef: deviceConfigDef.ShellShutter,
        createCallback: (function(_this) {
          return function(config, lastState) {
            return new ShellShutter(config, lastState);
          };
        })(this)
      });
      this.framework.deviceManager.registerDeviceClass("ShellSensor", {
        configDef: deviceConfigDef.ShellSensor,
        createCallback: (function(_this) {
          return function(config, lastState) {
            return new ShellSensor(config, lastState);
          };
        })(this)
      });
      this.framework.deviceManager.registerDeviceClass("ShellPresenceSensor", {
        configDef: deviceConfigDef.ShellPresenceSensor,
        createCallback: (function(_this) {
          return function(config, lastState) {
            return new ShellPresenceSensor(config, lastState);
          };
        })(this)
      });
      if (this.config.sequential) {
        realExec = exec;
        lastAction = Promise.resolve();
        return exec = function(command) {
          lastAction = settled(lastAction).then(function() {
            return realExec(command);
          });
          return lastAction;
        };
      }
    };

    return ShellExecute;

  })(env.plugins.Plugin);
  plugin = new ShellExecute();
  ShellSwitch = (function(superClass) {
    extend(ShellSwitch, superClass);

    function ShellSwitch(config1, lastState) {
      var ref, updateValue;
      this.config = config1;
      this.name = this.config.name;
      this.id = this.config.id;
      this.base = commons.base(this, this.config["class"]);
      this.forceExecution = this.config.forceExecution;
      this._state = (lastState != null ? (ref = lastState.state) != null ? ref.value : void 0 : void 0) || false;
      updateValue = (function(_this) {
        return function() {
          if (_this.config.interval > 0) {
            _this._updateValueTimeout = null;
            return _this.getState()["finally"](function() {
              return _this._updateValueTimeout = setTimeout(updateValue, _this.config.interval);
            });
          }
        };
      })(this);
      ShellSwitch.__super__.constructor.call(this);
      if (this.config.getStateCommand != null) {
        updateValue();
      }
    }

    ShellSwitch.prototype.destroy = function() {
      if (this._updateValueTimeout != null) {
        clearTimeout(this._updateValueTimeout);
      }
      return ShellSwitch.__super__.destroy.call(this);
    };

    ShellSwitch.prototype.getState = function() {
      if (this.config.getStateCommand == null) {
        return Promise.resolve(this._state);
      } else {
        return exec(this.config.getStateCommand).then((function(_this) {
          return function(arg) {
            var stderr, stdout;
            stdout = arg.stdout, stderr = arg.stderr;
            stdout = stdout.trim();
            switch (stdout) {
              case "on":
              case "true":
              case "1":
              case "t":
              case "o":
                _this._setState(true);
                return Promise.resolve(_this._state);
              case "off":
              case "false":
              case "0":
              case "f":
                _this._setState(false);
                return Promise.resolve(_this._state);
              default:
                if (stderr.length !== 0) {
                  _this.base.error("stderr output from getStateCommand for " + _this.name + ": " + stderr);
                }
                throw new Error("unknown state=\"" + stdout + "\"!");
            }
          };
        })(this))["catch"]((function(_this) {
          return function(error) {
            return _this.base.rejectWithErrorString(Promise.reject, transformError(error));
          };
        })(this));
      }
    };

    ShellSwitch.prototype.changeStateTo = function(state) {
      var command;
      if (this._state === state && !this.forceExecution) {
        return Promise.resolve();
      }
      command = (state ? this.config.onCommand : this.config.offCommand);
      return exec(command).then((function(_this) {
        return function(arg) {
          var stderr, stdout;
          stdout = arg.stdout, stderr = arg.stderr;
          if (stderr.length !== 0) {
            _this.base.error("stderr output from on/offCommand for " + _this.name + ": " + stderr);
          }
          return _this._setState(state);
        };
      })(this))["catch"]((function(_this) {
        return function(error) {
          return _this.base.rejectWithErrorString(Promise.reject, transformError(error));
        };
      })(this));
    };

    return ShellSwitch;

  })(env.devices.PowerSwitch);
  ShellShutter = (function(superClass) {
    extend(ShellShutter, superClass);

    function ShellShutter(config1, lastState) {
      var ref, updateValue;
      this.config = config1;
      this.name = this.config.name;
      this.id = this.config.id;
      this.base = commons.base(this, this.config["class"]);
      this.forceExecution = this.config.forceExecution;
      this._position = (lastState != null ? (ref = lastState.position) != null ? ref.value : void 0 : void 0) || 'stopped';
      updateValue = (function(_this) {
        return function() {
          if (_this.config.interval > 0) {
            _this._updateValueTimeout = null;
            return _this.getPosition()["finally"](function() {
              return _this._updateValueTimeout = setTimeout(updateValue, _this.config.interval);
            });
          }
        };
      })(this);
      ShellShutter.__super__.constructor.call(this);
      if (this.config.getStateCommand != null) {
        updateValue();
      }
    }

    ShellShutter.prototype.destroy = function() {
      if (this._updateValueTimeout != null) {
        clearTimeout(this._updateValueTimeout);
      }
      return ShellShutter.__super__.destroy.call(this);
    };

    ShellShutter.prototype.getPosition = function() {
      if (this.config.getStateCommand == null) {
        return Promise.resolve(this._position);
      } else {
        return exec(this.config.getStateCommand).then((function(_this) {
          return function(arg) {
            var stderr, stdout;
            stdout = arg.stdout, stderr = arg.stderr;
            stdout = stdout.trim();
            switch (stdout) {
              case "on":
              case "true":
              case "1":
              case "t":
              case "o":
              case "up":
                _this._setPosition(up);
                return Promise.resolve(_this._position);
              case "off":
              case "false":
              case "0":
              case "f":
              case "down":
                _this._setPosition(down);
                return Promise.resolve(_this._position);
              default:
                if (stderr.length !== 0) {
                  _this.base.error("stderr output from getStateCommand for " + _this.name + ": " + stderr);
                }
                throw new Error("unknown position=\"" + stdout + "\"!");
            }
          };
        })(this))["catch"]((function(_this) {
          return function(error) {
            return _this.base.rejectWithErrorString(Promise.reject, transformError(error));
          };
        })(this));
      }
    };

    ShellShutter.prototype.stop = function() {
      return this._setPosition('stopped');
    };

    ShellShutter.prototype.moveToPosition = function(position) {
      var check, command;
      if (this._position === position && !this.forceExecution) {
        return Promise.resolve();
      }
      command = (position === 'up' ? this.config.onCommand && (check = 1) : this.config.offCommand && (check = 2));
      return exec(command).then((function(_this) {
        return function(arg) {
          var stderr, stdout;
          stdout = arg.stdout, stderr = arg.stderr;
          if (stderr.length !== 0) {
            _this.base.error("stderr output from on/offCommand for " + _this.name + ": " + stderr);
          }
          return _this._setPosition(position);
        };
      })(this))["catch"]((function(_this) {
        return function(error) {
          return _this.base.rejectWithErrorString(Promise.reject, transformError(error));
        };
      })(this));
    };

    return ShellShutter;

  })(env.devices.ShutterController);
  ShellSensor = (function(superClass) {
    extend(ShellSensor, superClass);

    function ShellSensor(config1, lastState) {
      var attributeName, getter, ref, updateValue;
      this.config = config1;
      this.name = this.config.name;
      this.id = this.config.id;
      this.base = commons.base(this, this.config["class"]);
      attributeName = this.config.attributeName;
      this.attributeValue = lastState != null ? (ref = lastState[attributeName]) != null ? ref.value : void 0 : void 0;
      this.attributes = {};
      this.attributes[attributeName] = {
        description: attributeName,
        type: this.config.attributeType
      };
      if (this.config.attributeUnit.length > 0) {
        this.attributes[attributeName].unit = this.config.attributeUnit;
      }
      if (this.config.attributeAcronym.length > 0) {
        this.attributes[attributeName].acronym = this.config.attributeAcronym;
      }
      if (this.config.discrete != null) {
        this.attributes[attributeName].discrete = this.config.discrete;
      }
      getter = 'get' + attributeName[0].toUpperCase() + attributeName.slice(1);
      this[getter] = (function(_this) {
        return function() {
          if (_this.attributeValue != null) {
            return Promise.resolve(_this.attributeValue);
          } else {
            return _this._getUpdatedAttributeValue();
          }
        };
      })(this);
      updateValue = (function(_this) {
        return function() {
          if (_this.config.interval > 0) {
            _this._updateValueTimeout = null;
            return _this._getUpdatedAttributeValue()["finally"](function() {
              return _this._updateValueTimeout = setTimeout(updateValue, _this.config.interval);
            });
          }
        };
      })(this);
      ShellSensor.__super__.constructor.call(this);
      updateValue();
    }

    ShellSensor.prototype.destroy = function() {
      if (this._updateValueTimeout != null) {
        clearTimeout(this._updateValueTimeout);
      }
      return ShellSensor.__super__.destroy.call(this);
    };

    ShellSensor.prototype._getUpdatedAttributeValue = function() {
      return exec(this.config.command).then((function(_this) {
        return function(arg) {
          var stderr, stdout;
          stdout = arg.stdout, stderr = arg.stderr;
          if (stderr.length !== 0) {
            throw new Error("Error getting attribute value for " + _this.name + ": " + stderr);
          }
          _this.attributeValue = stdout.trim();
          if (_this.config.attributeType === "number") {
            _this.attributeValue = parseFloat(_this.attributeValue);
          }
          _this.emit(_this.config.attributeName, _this.attributeValue);
          return _this.attributeValue;
        };
      })(this))["catch"]((function(_this) {
        return function(error) {
          return _this.base.rejectWithErrorString(Promise.reject, transformError(error));
        };
      })(this));
    };

    return ShellSensor;

  })(env.devices.Sensor);
  ShellPresenceSensor = (function(superClass) {
    extend(ShellPresenceSensor, superClass);

    function ShellPresenceSensor(config1, lastState) {
      var ref, updateValue;
      this.config = config1;
      this.name = this.config.name;
      this.id = this.config.id;
      this.base = commons.base(this, this.config["class"]);
      this._presence = (lastState != null ? (ref = lastState.presence) != null ? ref.value : void 0 : void 0) || false;
      this._triggerAutoReset();
      updateValue = (function(_this) {
        return function() {
          if (_this.config.interval > 0) {
            _this._updateValueTimeout = null;
            return _this.getPresence()["finally"](function() {
              return _this._updateValueTimeout = setTimeout(updateValue, _this.config.interval);
            });
          }
        };
      })(this);
      ShellPresenceSensor.__super__.constructor.call(this);
      updateValue();
    }

    ShellPresenceSensor.prototype.destroy = function() {
      if (this._updateValueTimeout != null) {
        clearTimeout(this._updateValueTimeout);
      }
      if (this._resetPresenceTimeout != null) {
        clearTimeout(this._resetPresenceTimeout);
      }
      return ShellPresenceSensor.__super__.destroy.call(this);
    };

    ShellPresenceSensor.prototype._triggerAutoReset = function() {
      if (this.config.autoReset && this._presence) {
        if (this._resetPresenceTimeout != null) {
          clearTimeout(this._resetPresenceTimeout);
        }
        return this._resetPresenceTimeout = setTimeout(((function(_this) {
          return function() {
            _this._setPresence(false);
            return _this._resetPresenceTimeout = null;
          };
        })(this)), this.config.resetTime);
      }
    };

    ShellPresenceSensor.prototype.getPresence = function() {
      return exec(this.config.command).then((function(_this) {
        return function(arg) {
          var stderr, stdout;
          stdout = arg.stdout, stderr = arg.stderr;
          stdout = stdout.trim();
          switch (stdout) {
            case "present":
            case "true":
            case "1":
            case "t":
              _this._setPresence(true);
              _this._triggerAutoReset();
              return Promise.resolve(true);
            case "absent":
            case "false":
            case "0":
            case "f":
              _this._setPresence(false);
              return Promise.resolve(false);
            default:
              if (stderr.length !== 0) {
                _this.base.error("stderr output from presence command for " + _this.name + ": " + stderr);
              }
              throw new Error("unknown state=\"" + stdout + "\"!");
          }
        };
      })(this))["catch"]((function(_this) {
        return function(error) {
          return _this.base.rejectWithErrorString(Promise.reject, transformError(error));
        };
      })(this));
    };

    return ShellPresenceSensor;

  })(env.devices.PresenceSensor);
  ShellActionProvider = (function(superClass) {
    extend(ShellActionProvider, superClass);

    function ShellActionProvider(framework) {
      this.framework = framework;
      this.parseAction = bind(this.parseAction, this);
    }


    /*
    This function handles action in the form of `execute "some string"`
     */

    ShellActionProvider.prototype.parseAction = function(input, context) {
      var commandTokens, fullMatch, m, match, onEnd, retVal, setCommand;
      retVal = null;
      commandTokens = null;
      fullMatch = false;
      setCommand = (function(_this) {
        return function(m, tokens) {
          return commandTokens = tokens;
        };
      })(this);
      onEnd = (function(_this) {
        return function() {
          return fullMatch = true;
        };
      })(this);
      m = M(input, context).match("execute ").matchStringWithVars(setCommand);
      if (m.hadMatch()) {
        match = m.getFullMatch();
        return {
          token: match,
          nextInput: input.substring(match.length),
          actionHandler: new ShellActionHandler(this.framework, commandTokens)
        };
      } else {
        return null;
      }
    };

    return ShellActionProvider;

  })(env.actions.ActionProvider);
  ShellActionHandler = (function(superClass) {
    extend(ShellActionHandler, superClass);

    function ShellActionHandler(framework, commandTokens1) {
      this.framework = framework;
      this.commandTokens = commandTokens1;
      this.executeAction = bind(this.executeAction, this);
      this.base = commons.base(this, "ShellActionHandler");
    }


    /*
    This function handles action in the form of `execute "some string"`
     */

    ShellActionHandler.prototype.executeAction = function(simulate) {
      return this.framework.variableManager.evaluateStringExpression(this.commandTokens).then((function(_this) {
        return function(command) {
          if (simulate) {
            return __("would execute \"%s\"", command);
          } else {
            return exec(command).then(function(arg) {
              var stderr, stdout;
              stdout = arg.stdout, stderr = arg.stderr;
              if (stderr.length !== 0) {
                _this.base.error("stderr output from command " + command + ": " + stderr);
              }
              return __("executed \"%s\": %s", command, stdout.trim());
            })["catch"](function(error) {
              return _this.base.rejectWithErrorString(Promise.reject, transformError(error));
            });
          }
        };
      })(this));
    };

    return ShellActionHandler;

  })(env.actions.ActionHandler);
  return plugin;
};
